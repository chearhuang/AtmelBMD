/**
 * \file
 *
 * \brief main file
 *
 * Copyright (c) 2015 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

/*
 * Support and FAQ: visit <a href="http://www.atmel.com/design-support/">Atmel
 * Support</a>
 */

/*- Includes ---------------------------------------------------------------*/
#include <asf.h>
#include "platform.h"
#include "at_ble_api.h"
#include "console_serial.h"
#include "timer_hw.h"
#include "conf_serialdrv.h"
#include "conf_board.h"
#include "ble_manager.h"
#include "ble_utils.h"
#include "wearable.h"
#include "touch_api_ptc.h"
#include "touch_app.h"
#include "rtc.h"
#include "bme280\bme280_support.h"
#include "conf_sensor.h"
#include "veml6080\veml6080.h"
#include "bhi160.h"
#include "bhi160\bhy_uc_driver.h"
#include "i2c.h"
#include "serial_drv.h"
#include "adc_measure.h"

/* macros */
#define SAMPLE_DEBOUNCE_COUNT 4

/* enum variable */
enum status_code veml6080_sensor_status = STATUS_ERR_NOT_INITIALIZED;

/* variables */
BME280_RETURN_FUNCTION_TYPE bme280_sensor_status = ERROR;

//environment data to BLE 
environment_data_t environ_data;	
s32 env_temperature;
u32 env_pressure;
u32 env_humidity;
uint16_t als_data;
	
/* function prototypes */
void configure_wdt(void);
void get_environment_sensor_data(environment_data_t *env_data);
void enable_gclk1(void);
void initialise_led(void);


/* Watchdog configuration */
void configure_wdt(void)
{
	/* Create a new configuration structure for the Watchdog settings and fill
	* with the default module settings. */
	struct wdt_conf config_wdt;
	wdt_get_config_defaults(&config_wdt);
	/* Set the Watchdog configuration settings */
	config_wdt.always_on = false;
	//config_wdt.clock_source = GCLK_GENERATOR_4;
	config_wdt.timeout_period = WDT_PERIOD_2048CLK;
	/* Initialize and enable the Watchdog with the user settings */
	wdt_set_config(&config_wdt);
}

void get_environment_sensor_data(environment_data_t *env_data)
{	
	bme280_set_power_mode(BME280_FORCED_MODE);
	
	if(ERROR == bme280_read_pressure_temperature_humidity(&env_pressure, &env_temperature, &env_humidity)){
		//error
		DBG_LOG("Reading BME280 has failed");
	}
	if(STATUS_OK != veml6080_read_alsdata(&als_data)){
		//error
		DBG_LOG("Reading VEML6080 has failed");
	}
	
	/* Temperature: No data processing required for Temperature data. Data with resolution 0.01(x100) directly txd*/
	env_data->temperature = (int16_t)env_temperature;
	/* Pressure: Returns pressure in Pa as unsigned 32 bit integer. Output value of �96386� equals 96386 Pa = 963.86 hPa*/
	env_data->pressure = (uint16_t)(env_pressure / 100);
	/*ALS: lx/step = 0.07 */
	env_data->uv = ((uint32_t)als_data * 7000);
	/* Humidity: An output value of 42313 represents 42313 / 1024 = 41.321 %rH*/
	env_data->humidity = (uint8_t)(env_humidity / 1024);
}

void enable_gclk1(void)
{
	struct system_gclk_gen_config gclk_conf;
	
	system_gclk_init();	
	gclk_conf.high_when_disabled = false;
	gclk_conf.source_clock       = GCLK_SOURCE_OSC16M;
	gclk_conf.division_factor = 1;
	gclk_conf.run_in_standby  = true;
	gclk_conf.output_enable   = false;
	system_gclk_gen_set_config(1, &gclk_conf);
	system_gclk_gen_enable(1);
}

void initialise_led(void)
{
	/* led port pin initialization */
	struct port_config config_port_pin;
	port_get_config_defaults(&config_port_pin);
	config_port_pin.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(BLE_LED, &config_port_pin);
	port_pin_set_config(TOUCH_LED, &config_port_pin);
	port_pin_set_config(POWER_LED, &config_port_pin);
	port_pin_set_output_level(BLE_LED, 1);
	port_pin_set_output_level(TOUCH_LED, 1);
	port_pin_set_output_level(POWER_LED, 0);
}

/* main function */
int main(void)
{
	/* initialize LED */
	initialise_led();
	
	enable_gclk1();
	//i2c configure
	configure_sensor_i2c();
	//Initialize BHI160
	bhy_driver_init(_bhi_fw, _bhi_fw_len);
	
	/* system clock initialization */
	system_init();
	
	/* delay routine initialization */
	delay_init();

	/* Initialize RTC */
	rtc_init();	
	
	/* configure adc for battery measurement */
	configure_adc();

	/* Initialize QTouch library and configure touch sensors */
	touch_sensors_init();

#ifdef DEBUG_SUPPORT
	/* Initialize serial console for debugging */
	serial_console_init();
#endif

	DBG_LOG("Initializing Wearable Demo Device");
	
	/* Hardware timer */
	hw_timer_init();

	//Initialize bme280
	wearable_bme280_init();
	//Initialize veml6080
	veml6080_init();		
	
	/* initialize the BLE chip  and Set the Device Address */
	ble_device_init(NULL);

	/* Register Primary/Included service in case of GATT Server */	
	wbe_profile_init();
	
	DBG_LOG("System in standby");	
	
	turn_off_power_led();
	
	/* disable peripherals to save power */
	disable_usart();
	disable_i2c();
	disable_adc();
	disable_hw_timer();	
	
	/* sleep mode initialization */
	system_set_sleepmode(SYSTEM_SLEEPMODE_STANDBY);
	
	/* configure watchdog timer */
	//configure_wdt();	
	
	while(true)
	{
		/* touch sensor measurement state machine */
		touch_meas_state_machine();
		
		if(system_state == SYSTEM_ACTIVE)
		{
			/* 20ms tick */
			if(tick_bhi == 1)
			{
				tick_bhi = 0;
				process_motion_sensor_data();
				if(step_detected)
				{
					step_detected = false;
					ble_notify_accelero_step_detection();
				}
			}
					
			if(tick_ble_event_task == 1)
			{
				tick_ble_event_task = 0;
				/* BLE Event task */
				ble_event_task();
			}
		
			if(tick_env_sensor == 1)
			{
				tick_env_sensor = 0;
				
				if(is_ble_env_char_notification_enabled())
				{
					get_environment_sensor_data(&environ_data);
					ble_notify_environment_data(&environ_data);
				}
			}
		
			if(tick_motion_sensor)
			{
				tick_motion_sensor = 0;
			
				if(is_ble_accelero_char_notification_enabled())
				{
					ble_notify_accelero_positions(&acc_data);
				}

				if(is_ble_gyro_char_notification_enabled())
				{
					ble_notify_gyro_positions(&gyro_data);
				}
			
				if(is_ble_rotation_vector_char_notification_enabled())
				{
					ble_notify_device_rotation_vector(&quaternion_data);
				}				
			}
		
			if(tick_60second)
			{
				tick_60second = 0;
				read_battery_voltage();
				if(is_ble_low_bat_char_notification_enabled())
				{
					if(low_battery_status)
					{
						low_battery_status = false;
						ble_notify_low_battery();
						low_battery_flag = true; // flag not reset until the power cycle
					}
				}
			}
			if(tick_1second)
			{
				tick_1second = 0;
				if(is_ble_drop_char_notification_enabled())
				{
					if(device_drop_detected >SAMPLE_DEBOUNCE_COUNT) 
					{
						device_drop_detected = 0;
						ble_notify_device_drop_detection();
					}
				}
				else
				{
					device_drop_detected = 0;
				}
			}					
		}
		
		/* reset watchdog timer */
		//wdt_reset_count();
		
		if( sleep_Enable == 1)
		{
			system_sleep();
		}
	}
}


